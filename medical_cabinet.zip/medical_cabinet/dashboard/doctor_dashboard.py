"""
Doctor Dashboard
Main interface for doctors with diagnostic management
"""

import customtkinter as ctk
from tkinter import ttk, messagebox
from datetime import datetime
import sys
sys.path.append('/home/ubuntu/medical_cabinet')

from config.theme import COLORS, THEME, STYLES
from config.db_config import DatabaseConfig
from utils.export_utils import ExportUtils


class DoctorDashboard(ctk.CTk):
    """
    Doctor dashboard class
    """
    
    def __init__(self, current_user):
        super().__init__()
        
        # Configure window
        self.title("Dashboard - Docteur")
        self.geometry("1200x800")
        self.resizable(True, True)
        
        # Set appearance mode
        ctk.set_appearance_mode(THEME["appearance_mode"])
        ctk.set_default_color_theme("blue")
        
        # Initialize
        self.current_user = current_user
        self.db_config = DatabaseConfig()
        self.connection = None
        
        # Current selected patient
        self.patients_card = None
        self.diagnostics_card = None
        self.diagnostics_today_card = None
            
        # Create UI
        self.create_widgets()
        
    def create_widgets(self):
        """
        Create dashboard interface widgets
        """
        # Main container
        self.main_container = ctk.CTkFrame(
            self,
            fg_color=COLORS['white']
        )
        self.main_container.pack(fill="both", expand=True)
        
        # Header
        self.create_header()
        
        # Main content
        self.main_content = ctk.CTkFrame(
            self.main_container,
            fg_color="transparent"
        )
        self.main_content.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Sidebar
        self.create_sidebar()
        
        # Content area
        self.create_content_area()
        
        # Load initial data
        self.load_patients()
        
    def create_header(self):
        """
        Create header section
        """
        self.header = ctk.CTkFrame(
            self.main_container,
            fg_color=COLORS['header_bg'],
            height=STYLES['header_height']
        )
        self.header.pack(fill="x", padx=20, pady=(20, 0))
        self.header.pack_propagate(False)
        
        # Header content
        self.header_content = ctk.CTkFrame(
            self.header,
            fg_color="transparent"
        )
        self.header_content.pack(fill="both", expand=True, padx=20, pady=10)
        
        # Title
        self.title_label = ctk.CTkLabel(
            self.header_content,
            text="Dashboard Docteur",
            font=("Segoe UI", 20, "bold"),
            text_color=COLORS['text_primary']
        )
        self.title_label.pack(side="left")
        
        # User info
        self.user_frame = ctk.CTkFrame(
            self.header_content,
            fg_color="transparent"
        )
        self.user_frame.pack(side="right")
        
        self.user_label = ctk.CTkLabel(
            self.user_frame,
            text=f"👤 {self.current_user['username']}",
            font=("Segoe UI", 12, "bold"),
            text_color=COLORS['primary']
        )
        self.user_label.pack(side="left", padx=(0, 10))
        
        self.logout_button = ctk.CTkButton(
            self.user_frame,
            text="Déconnexion",
            font=("Segoe UI", 11),
            height=30,
            width=100,
            fg_color=COLORS['btn_danger'],
            hover_color=COLORS['btn_danger_hover'],
            command=self.logout
        )
        self.logout_button.pack(side="right")
        
    def create_sidebar(self):
        """
        Create sidebar with navigation
        """
        self.sidebar = ctk.CTkFrame(
            self.main_content,
            fg_color=COLORS['sidebar_bg'],
            width=STYLES['sidebar_width']
        )
        self.sidebar.pack(side="left", fill="y", padx=(0, 20))
        self.sidebar.pack_propagate(False)
        
        # Sidebar content
        self.sidebar_content = ctk.CTkFrame(
            self.sidebar,
            fg_color="transparent"
        )
        self.sidebar_content.pack(fill="both", expand=True, padx=20, pady=30)
        
        # Navigation buttons
        
        # Patients button
        self.patients_btn = ctk.CTkButton(
            self.sidebar_content,
            text="👥 Liste des Patients",
            font=("Segoe UI", 13, "bold"),
            height=45,
            corner_radius=8,
            fg_color=COLORS['sidebar_bg'],
            hover_color=COLORS['sidebar_hover'],
            text_color=COLORS['sidebar_text'],
            anchor="w",
            command=self.show_patients
        )
        self.patients_btn.pack(fill="x", pady=(0, 10))
        
        # Statistics button
        self.stats_btn = ctk.CTkButton(
            self.sidebar_content,
            text="📊 Statistiques",
            font=("Segoe UI", 13, "bold"),
            height=45,
            corner_radius=8,
            fg_color=COLORS['sidebar_bg'],
            hover_color=COLORS['sidebar_hover'],
            text_color=COLORS['sidebar_text'],
            anchor="w",
            command=self.show_statistics
        )
        self.stats_btn.pack(fill="x", pady=(0, 10))
        
        # Export button
        self.export_btn = ctk.CTkButton(
            self.sidebar_content,
            text="📤 Exporter Diagnostics",
            font=("Segoe UI", 13, "bold"),
            height=45,
            corner_radius=8,
            fg_color=COLORS['sidebar_bg'],
            hover_color=COLORS['sidebar_hover'],
            text_color=COLORS['sidebar_text'],
            anchor="w",
            command=self.export_diagnostics
        )
        self.export_btn.pack(fill="x", pady=(0, 10))
        
    def create_content_area(self):
        """
        Create main content area
        """
        self.content_area = ctk.CTkFrame(
            self.main_content,
            fg_color=COLORS['white']
        )
        self.content_area.pack(fill="both", expand=True)
        
        # Patients tab (default)
        self.patients_tab = ctk.CTkFrame(self.content_area, fg_color="transparent")
        self.patients_tab.pack(fill="both", expand=True)
        
        # Create patients tab content
        self.create_patients_tab()
        
        # Statistics tab
        self.stats_tab = ctk.CTkFrame(self.content_area, fg_color="transparent")
        
    def create_patients_tab(self):
        """
        Create patients management tab
        """
        # Top controls
        self.patients_controls = ctk.CTkFrame(
            self.patients_tab,
            fg_color="transparent"
        )
        self.patients_controls.pack(fill="x", padx=20, pady=(20, 10))
        
        # Title
        self.patients_title = ctk.CTkLabel(
            self.patients_controls,
            text="Liste des Patients",
            font=("Segoe UI", 20, "bold"),
            text_color=COLORS['text_primary']
        )
        self.patients_title.pack(side="left")
        
        # Search bar
        self.search_frame = ctk.CTkFrame(
            self.patients_controls,
            fg_color="transparent"
        )
        self.search_frame.pack(side="right")
        
        self.search_entry = ctk.CTkEntry(
            self.search_frame,
            placeholder_text="Rechercher un patient...",
            font=("Segoe UI", 12),
            height=35,
            corner_radius=6,
            fg_color=COLORS['gray_light'],
            border_color=COLORS['gray'],
            border_width=1
        )
        self.search_entry.pack(side="left", padx=(0, 10))
        
        self.search_btn = ctk.CTkButton(
            self.search_frame,
            text="🔍 Rechercher",
            font=("Segoe UI", 12, "bold"),
            height=35,
            width=120,
            fg_color=COLORS['btn_primary'],
            hover_color=COLORS['btn_primary_hover'],
            command=self.search_patients
        )
        self.search_btn.pack(side="right")
        
        # Patients table
        self.patients_table_frame = ctk.CTkFrame(
            self.patients_tab,
            fg_color="transparent"
        )
        self.patients_table_frame.pack(fill="both", expand=True, padx=20, pady=(10, 20))
        
        # Treeview with scrollbar
        self.patients_tree = ttk.Treeview(
            self.patients_table_frame,
            columns=("ID", "Nom", "Prénom", "CIN", "Âge", "Téléphone"),
            show="headings",
            height=20
        )
        
        # Configure columns
        self.patients_tree.heading("ID", text="ID", anchor="center")
        self.patients_tree.heading("Nom", text="Nom", anchor="center")
        self.patients_tree.heading("Prénom", text="Prénom", anchor="center")
        self.patients_tree.heading("CIN", text="CIN", anchor="center")
        self.patients_tree.heading("Âge", text="Âge", anchor="center")
        self.patients_tree.heading("Téléphone", text="Téléphone", anchor="center")
        
        self.patients_tree.column("ID", width=50, anchor="center", stretch=False)
        self.patients_tree.column("Nom", width=120, anchor="center")
        self.patients_tree.column("Prénom", width=120, anchor="center")
        self.patients_tree.column("CIN", width=100, anchor="center")
        self.patients_tree.column("Âge", width=60, anchor="center", stretch=False)
        self.patients_tree.column("Téléphone", width=120, anchor="center")
        
        # Style the treeview
        style = ttk.Style()
        style.theme_use("default")
        style.configure("Treeview",
                       background=COLORS['white'],
                       foreground=COLORS['text_primary'],
                       rowheight=25,
                       fieldbackground=COLORS['white'])
        style.map('Treeview',
                 background=[('selected', COLORS['primary'])])
        
        # Scrollbar
        scrollbar = ttk.Scrollbar(
            self.patients_table_frame,
            orient="vertical",
            command=self.patients_tree.yview
        )
        self.patients_tree.configure(yscrollcommand=scrollbar.set)
        
        # Pack widgets
        self.patients_tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # Bind selection event
        self.patients_tree.bind("<<TreeviewSelect>>", self.on_patient_select)
        
    def create_statistics_tab(self):
        """
        Create statistics tab
        """
        # Main frame
        self.stats_main = ctk.CTkFrame(
            self.stats_tab,
            fg_color="transparent"
        )
        self.stats_main.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Title
        self.stats_title = ctk.CTkLabel(
            self.stats_main,
            text="Statistiques",
            font=("Segoe UI", 24, "bold"),
            text_color=COLORS['text_primary']
        )
        self.stats_title.pack(pady=(0, 30))
        
        # Statistics cards
        self.stats_cards_frame = ctk.CTkFrame(
            self.stats_main,
            fg_color="transparent"
        )
        self.stats_cards_frame.pack(fill="x", padx=20)
        
        # Patients card
        self.patients_card = self.create_stat_card(
            self.stats_cards_frame,
            "Total Patients",
            "0",
            "👥"
        )
        self.patients_card.pack(side="left", padx=(0, 20))
        
        # Diagnostics card
        self.diagnostics_card = self.create_stat_card(
            self.stats_cards_frame,
            "Total Diagnostics",
            "0",
            "📋"
        )
        self.diagnostics_card.pack(side="left", padx=(0, 20))
        
        # Diagnostics today card
        self.diagnostics_today_card = self.create_stat_card(
            self.stats_cards_frame,
            "Diagnostics Aujourd'hui",
            "0",
            "📅"
        )
        self.diagnostics_today_card.pack(side="left")
        
    def create_stat_card(self, parent, title, value, icon):
        """
        Create a statistics card
        
        Args:
            parent: Parent widget
            title: Card title
            value: Card value
            icon: Card icon
        
        Returns:
            Card frame
        """
        card = ctk.CTkFrame(
            parent,
            fg_color=COLORS['card_bg'],
            corner_radius=10,
            border_width=1,
            border_color=COLORS['card_border']
        )
        
        icon_label = ctk.CTkLabel(
            card,
            text=icon,
            font=("Segoe UI", 40),
            text_color=COLORS['primary']
        )
        icon_label.pack(pady=(15, 10))
        
        title_label = ctk.CTkLabel(
            card,
            text=title,
            font=("Segoe UI", 14, "bold"),
            text_color=COLORS['text_secondary']
        )
        title_label.pack(pady=(0, 10))
        
        value_label = ctk.CTkLabel(
            card,
            text=value,
            font=("Segoe UI", 32, "bold"),
            text_color=COLORS['primary']
        )
        value_label.pack(pady=(0, 15))
        
        return card
        
    def show_patients(self):
        """
        Show patients tab
        """
        self.patients_tab.pack(fill="both", expand=True)
        self.stats_tab.pack_forget()
        
    def show_statistics(self):
        """
        Show statistics tab
        """
        self.patients_tab.pack_forget()
        self.stats_tab.pack(fill="both", expand=True)
        if self.patients_card is None:
            self.create_statistics_tab()

        # Load statistics
        self.load_statistics()
        
    def load_patients(self):
        """
        Load patients data from database
        """
        # Clear existing data
        for item in self.patients_tree.get_children():
            self.patients_tree.delete(item)
        
        # Connect to database
        self.connection = self.db_config.connect()
        
        if not self.connection:
            messagebox.showerror("Erreur", "Impossible de se connecter à la base de données")
            return
        
        try:
            cursor = self.connection.cursor(dictionary=True)
            query = "SELECT * FROM patients ORDER BY nom, prenom"
            cursor.execute(query)
            patients = cursor.fetchall()
            
            # Insert data into treeview
            for patient in patients:
                self.patients_tree.insert(
                    "",
                    "end",
                    values=(
                        patient['id'],
                        patient['nom'],
                        patient['prenom'],
                        patient['cin'] or "N/A",
                        patient['age'] or "N/A",
                        patient['telephone'] or "N/A"
                    ),
                    tags=(patient['id'],)
                )
                
        except Exception as e:
            messagebox.showerror("Erreur", f"Erreur lors du chargement des patients: {e}")
        
        finally:
            if cursor:
                cursor.close()
            if self.connection:
                self.db_config.close_connection(self.connection)
                self.connection = None
                
    def load_statistics(self):
        """
        Load and display statistics
        """
        # Connect to database
        self.connection = self.db_config.connect()
        
        if not self.connection:
            return
        
        try:
            cursor = self.connection.cursor(dictionary=True)
            
            # Total patients
            cursor.execute("SELECT COUNT(*) as count FROM patients")
            total_patients = cursor.fetchone()['count']
            
            # Total diagnostics
            cursor.execute("SELECT COUNT(*) as count FROM diagnostics")
            total_diagnostics = cursor.fetchone()['count']
            
            # Diagnostics today
            today = datetime.now().strftime("%Y-%m-%d")
            cursor.execute("SELECT COUNT(*) as count FROM diagnostics WHERE date_diagnostic = %s", (today,))
            diagnostics_today = cursor.fetchone()['count']
            
            # Update cards
            self.patients_card.winfo_children()[2].configure(text=str(total_patients))
            self.diagnostics_card.winfo_children()[2].configure(text=str(total_diagnostics))
            self.diagnostics_today_card.winfo_children()[2].configure(text=str(diagnostics_today))
            
        except Exception as e:
            print(f"Erreur lors du chargement des statistiques: {e}")
        
        finally:
            if cursor:
                cursor.close()
            if self.connection:
                self.db_config.close_connection(self.connection)
                self.connection = None
                
    def on_patient_select(self, event):
        """
        Handle patient selection
        
        Args:
            event: Selection event
        """
        selected_items = self.patients_tree.selection()
        
        if selected_items:
            item = selected_items[0]
            patient_id = self.patients_tree.item(item, "tags")[0]
            self.selected_patient_id = patient_id
            
            # Open patient dossier
            self.open_patient_dossier(patient_id)
            
    def open_patient_dossier(self, patient_id):
        """
        Open patient medical dossier
        
        Args:
            patient_id: ID of the selected patient
        """
        # Create new window for patient dossier
        dossier_window = ctk.CTkToplevel(self)
        dossier_window.title("Dossier Médical")
        dossier_window.geometry("1000x700")
        dossier_window.resizable(True, True)
        
        # Set modal
        dossier_window.transient(self)
        dossier_window.grab_set()
        
        # Create dossier content
        self.create_patient_dossier(dossier_window, patient_id)
        
    def create_patient_dossier(self, parent, patient_id):
        """
        Create patient medical dossier
        
        Args:
            parent: Parent window
            patient_id: ID of the patient
        """
        # Main frame
        main_frame = ctk.CTkFrame(
            parent,
            fg_color="white"
        )
        main_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Header
        header_frame = ctk.CTkFrame(
            main_frame,
            fg_color=COLORS['primary'],
            corner_radius=10
        )
        header_frame.pack(fill="x", pady=(0, 20))
        
        # Patient info
        patient_info = self.get_patient_info(patient_id)
        
        if patient_info:
            patient_name = f"{patient_info['nom']} {patient_info['prenom']}"
            
            name_label = ctk.CTkLabel(
                header_frame,
                text=patient_name,
                font=("Segoe UI", 24, "bold"),
                text_color="white"
            )
            name_label.pack(pady=20, padx=20)
            
            info_text = f"CIN: {patient_info['cin'] or 'N/A'} | Âge: {patient_info['age'] or 'N/A'} | Téléphone: {patient_info['telephone'] or 'N/A'}"
            info_label = ctk.CTkLabel(
                header_frame,
                text=info_text,
                font=("Segoe UI", 12),
                text_color="white"
            )
            info_label.pack(pady=(0, 20), padx=20)
            
        # Content area
        content_frame = ctk.CTkFrame(
            main_frame,
            fg_color="transparent"
        )
        content_frame.pack(fill="both", expand=True)
        
        # Left: Old diagnostics
        old_diagnostics_frame = ctk.CTkFrame(
            content_frame,
            fg_color=COLORS['card_bg'],
            corner_radius=10,
            border_width=1,
            border_color=COLORS['card_border']
        )
        old_diagnostics_frame.pack(side="left", fill="both", expand=True, padx=(0, 10))
        
        old_diagnostics_title = ctk.CTkLabel(
            old_diagnostics_frame,
            text="Diagnostics Antérieurs",
            font=("Segoe UI", 16, "bold"),
            text_color=COLORS['text_primary']
        )
        old_diagnostics_title.pack(pady=(15, 10), padx=15)
        
        # Old diagnostics table
        old_diagnostics_tree = ttk.Treeview(
            old_diagnostics_frame,
            columns=("Date", "Diagnostic"),
            show="headings",
            height=15
        )
        
        old_diagnostics_tree.heading("Date", text="Date", anchor="center")
        old_diagnostics_tree.heading("Diagnostic", text="Diagnostic", anchor="center")
        
        old_diagnostics_tree.column("Date", width=120, anchor="center", stretch=False)
        old_diagnostics_tree.column("Diagnostic", width=400, anchor="center")
        
        # Style
        style = ttk.Style()
        style.theme_use("default")
        style.configure("Treeview",
                       background=COLORS['white'],
                       foreground=COLORS['text_primary'],
                       rowheight=30,
                       fieldbackground=COLORS['white'])
        
        # Scrollbar
        scrollbar = ttk.Scrollbar(
            old_diagnostics_frame,
            orient="vertical",
            command=old_diagnostics_tree.yview
        )
        old_diagnostics_tree.configure(yscrollcommand=scrollbar.set)
        
        # Load old diagnostics
        old_diagnostics_tree.pack(side="left", fill="both", expand=True, padx=10, pady=10)
        scrollbar.pack(side="right", fill="y")
        
        self.load_old_diagnostics(old_diagnostics_tree, patient_id)
        
        # Right: New diagnostic
        new_diagnostic_frame = ctk.CTkFrame(
            content_frame,
            fg_color=COLORS['card_bg'],
            corner_radius=10,
            border_width=1,
            border_color=COLORS['card_border']
        )
        new_diagnostic_frame.pack(side="right", fill="both", expand=True, padx=(10, 0))
        
        new_diagnostic_title = ctk.CTkLabel(
            new_diagnostic_frame,
            text="Nouveau Diagnostic",
            font=("Segoe UI", 16, "bold"),
            text_color=COLORS['text_primary']
        )
        new_diagnostic_title.pack(pady=(15, 10), padx=15)
        
        # Diagnostic textbox
        diagnostic_textbox = ctk.CTkTextbox(
            new_diagnostic_frame,
            font=("Segoe UI", 12),
            height=200,
            corner_radius=6,
            fg_color=COLORS['white'],
            border_color=COLORS['gray'],
            border_width=1
        )
        diagnostic_textbox.pack(fill="both", expand=True, padx=15, pady=(0, 15))
        
        # Save button
        save_btn = ctk.CTkButton(
            new_diagnostic_frame,
            text="Enregistrer Diagnostic",
            font=("Segoe UI", 12, "bold"),
            height=40,
            fg_color=COLORS['btn_success'],
            hover_color=COLORS['btn_success_hover'],
            command=lambda: self.save_diagnostic(
                patient_id,
                diagnostic_textbox.get("1.0", "end").strip(),
                parent
            )
        )
        save_btn.pack(pady=(0, 15), padx=15)
        
        # Print button
        print_btn = ctk.CTkButton(
            new_diagnostic_frame,
            text="📥 Exporter PDF",
            font=("Segoe UI", 12, "bold"),
            height=40,
            fg_color=COLORS['btn_primary'],
            hover_color=COLORS['btn_primary_hover'],
            command=lambda: self.export_diagnostic_pdf(
                patient_id,
                diagnostic_textbox.get("1.0", "end").strip()
            )
        )
        print_btn.pack(pady=(0, 15), padx=15)
        
    def get_patient_info(self, patient_id):
        """
        Get patient information
        
        Args:
            patient_id: ID of the patient
        
        Returns:
            Patient information dictionary
        """
        # Connect to database
        self.connection = self.db_config.connect()
        
        if not self.connection:
            return None
        
        try:
            cursor = self.connection.cursor(dictionary=True)
            query = "SELECT * FROM patients WHERE id = %s"
            cursor.execute(query, (patient_id,))
            patient = cursor.fetchone()
            return patient
            
        except Exception as e:
            print(f"Erreur lors de la récupération des informations du patient: {e}")
            return None
        
        finally:
            if cursor:
                cursor.close()
            if self.connection:
                self.db_config.close_connection(self.connection)
                self.connection = None
                
    def load_old_diagnostics(self, treeview, patient_id):
        """
        Load old diagnostics for patient
        
        Args:
            treeview: Treeview widget
            patient_id: ID of the patient
        """
        # Clear existing data
        for item in treeview.get_children():
            treeview.delete(item)
        
        # Connect to database
        self.connection = self.db_config.connect()
        
        if not self.connection:
            return
        
        try:
            cursor = self.connection.cursor(dictionary=True)
            query = """
                SELECT d.*, u.username as doctor_name 
                FROM diagnostics d
                JOIN users u ON d.doctor_id = u.id
                WHERE d.patient_id = %s
                ORDER BY d.date_diagnostic DESC
            """
            cursor.execute(query, (patient_id,))
            diagnostics = cursor.fetchall()
            
            # Insert data into treeview
            for diagnostic in diagnostics:
                date_str = diagnostic['date_diagnostic'].strftime("%d/%m/%Y")
                diagnostic_text = f"{diagnostic['diagnostic']}\n(Par: {diagnostic['doctor_name']})"
                treeview.insert(
                    "",
                    "end",
                    values=(date_str, diagnostic_text),
                    tags=(diagnostic['id'],)
                )
                
        except Exception as e:
            print(f"Erreur lors du chargement des diagnostics: {e}")
        
        finally:
            if cursor:
                cursor.close()
            if self.connection:
                self.db_config.close_connection(self.connection)
                self.connection = None
                
    def save_diagnostic(self, patient_id, diagnostic_text, parent_window):
        """
        Save new diagnostic
        
        Args:
            patient_id: ID of the patient
            diagnostic_text: Diagnostic text
            parent_window: Parent window to close
        """
        if not diagnostic_text:
            messagebox.showwarning("Avertissement", "Veuillez entrer un diagnostic")
            return
        
        # Connect to database
        self.connection = self.db_config.connect()
        
        if not self.connection:
            messagebox.showerror("Erreur", "Impossible de se connecter à la base de données")
            return
        
        try:
            cursor = self.connection.cursor()
            
            # Insert diagnostic
            query = """
                INSERT INTO diagnostics (patient_id, doctor_id, diagnostic, date_diagnostic)
                VALUES (%s, %s, %s, CURDATE())
            """
            cursor.execute(query, (patient_id, self.current_user['id'], diagnostic_text))
            self.connection.commit()
            
            messagebox.showinfo("Succès", "Diagnostic enregistré avec succès")
            
            # Close parent window
            parent_window.destroy()
            
        except Exception as e:
            messagebox.showerror("Erreur", f"Erreur lors de l'enregistrement: {e}")
        
        finally:
            if cursor:
                cursor.close()
            if self.connection:
                self.db_config.close_connection(self.connection)
                self.connection = None
                
    def export_diagnostic_pdf(self, patient_id, diagnostic_text):
        """
        Export diagnostic to PDF
        
        Args:
            patient_id: ID of the patient
            diagnostic_text: Diagnostic text
        """
        if not diagnostic_text:
            messagebox.showwarning("Avertissement", "Aucun diagnostic à exporter")
            return
        
        # Get patient info
        patient_info = self.get_patient_info(patient_id)
        
        if not patient_info:
            messagebox.showerror("Erreur", "Impossible de récupérer les informations du patient")
            return
        
        # Export to PDF
        success, filename, error_message = ExportUtils.export_diagnostic_to_pdf(
            patient_info,
            diagnostic_text,
            self.current_user['username']
        )
        
        if success:
            messagebox.showinfo("Succès", f"Le diagnostic a été exporté avec succès!\n\nFichier: {filename}")
        else:
            messagebox.showerror("Erreur", error_message)
        
    def search_patients(self):
        """
        Search patients by name
        """
        search_term = self.search_entry.get().strip().lower()
        
        if not search_term:
            self.load_patients()
            return
        
        # Clear existing data
        for item in self.patients_tree.get_children():
            self.patients_tree.delete(item)
        
        # Connect to database
        self.connection = self.db_config.connect()
        
        if not self.connection:
            messagebox.showerror("Erreur", "Impossible de se connecter à la base de données")
            return
        
        try:
            cursor = self.connection.cursor(dictionary=True)
            query = """
                SELECT * FROM patients 
                WHERE LOWER(nom) LIKE %s OR LOWER(prenom) LIKE %s
                ORDER BY nom, prenom
            """
            cursor.execute(query, (f"%{search_term}%", f"%{search_term}%"))
            patients = cursor.fetchall()
            
            # Insert data into treeview
            for patient in patients:
                self.patients_tree.insert(
                    "",
                    "end",
                    values=(
                        patient['id'],
                        patient['nom'],
                        patient['prenom'],
                        patient['cin'] or "N/A",
                        patient['age'] or "N/A",
                        patient['telephone'] or "N/A"
                    ),
                    tags=(patient['id'],)
                )
                
        except Exception as e:
            messagebox.showerror("Erreur", f"Erreur lors de la recherche: {e}")
        
        finally:
            if cursor:
                cursor.close()
            if self.connection:
                self.db_config.close_connection(self.connection)
                self.connection = None
                
    def export_diagnostics(self):
        """
        Export diagnostics to PDF
        """
        ExportUtils.export_all_diagnostics_to_pdf(self.db_config)
        
    def logout(self):
        """
        Logout and return to login
        """
        self.destroy()
        from login import LoginWindow
        login = LoginWindow()
        login.mainloop()


if __name__ == "__main__":
    # For testing purposes
    from login import LoginWindow
    login = LoginWindow()
    login.mainloop()
