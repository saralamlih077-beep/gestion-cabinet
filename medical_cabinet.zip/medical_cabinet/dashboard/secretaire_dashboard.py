"""
Secretaire Dashboard
Main interface for medical secretary with patient and appointment management
"""

import customtkinter as ctk
from tkinter import ttk, messagebox
from datetime import datetime
import sys
sys.path.append('/home/ubuntu/medical_cabinet')

from config.theme import COLORS, THEME, STYLES
from config.db_config import DatabaseConfig
from patients.patient_form import PatientForm
from appointments.appointment_form import AppointmentForm
from utils.export_utils import ExportUtils


class SecretaireDashboard(ctk.CTk):
    """
    Secretaire dashboard class
    """
    
    def __init__(self, current_user):
        super().__init__()
        
        # Configure window
        self.title("Dashboard - Secrétaire")
        self.geometry("1400x800")
        self.resizable(True, True)
        
        # Set appearance mode
        ctk.set_appearance_mode(THEME["appearance_mode"])
        ctk.set_default_color_theme("blue")
        
        # Initialize
        self.current_user = current_user
        self.db_config = DatabaseConfig()
        self.connection = None
        
        # Current selected patient
        self.selected_patient_id = None
        
        # Initialize appointments_tree to None
        self.appointments_tree = None
        
        # Create UI
        self.create_widgets()
        
    def create_widgets(self):
        """
        Create dashboard interface widgets
        """
        # Main container
        self.main_container = ctk.CTkFrame(
            self,
            fg_color=COLORS['white']
        )
        self.main_container.pack(fill="both", expand=True)
        
        # Header
        self.create_header()
        
        # Main content with sidebar and content area
        self.main_content = ctk.CTkFrame(
            self.main_container,
            fg_color="transparent"
        )
        self.main_content.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Sidebar
        self.create_sidebar()
        
        # Content area
        self.create_content_area()
        
        # Load initial data
        self.load_patients()
        
    def create_header(self):
        """
        Create header section
        """
        self.header = ctk.CTkFrame(
            self.main_container,
            fg_color=COLORS['header_bg'],
            height=STYLES['header_height']
        )
        self.header.pack(fill="x", padx=20, pady=(20, 0))
        self.header.pack_propagate(False)
        
        # Header content
        self.header_content = ctk.CTkFrame(
            self.header,
            fg_color="transparent"
        )
        self.header_content.pack(fill="both", expand=True, padx=20, pady=10)
        
        # Title
        self.title_label = ctk.CTkLabel(
            self.header_content,
            text="Dashboard Secrétaire",
            font=("Segoe UI", 20, "bold"),
            text_color=COLORS['text_primary']
        )
        self.title_label.pack(side="left")
        
        # User info
        self.user_frame = ctk.CTkFrame(
            self.header_content,
            fg_color="transparent"
        )
        self.user_frame.pack(side="right")
        
        self.user_label = ctk.CTkLabel(
            self.user_frame,
            text=f"👤 {self.current_user['username']}",
            font=("Segoe UI", 12, "bold"),
            text_color=COLORS['primary']
        )
        self.user_label.pack(side="left", padx=(0, 10))
        
        self.logout_button = ctk.CTkButton(
            self.user_frame,
            text="Déconnexion",
            font=("Segoe UI", 11),
            height=30,
            width=100,
            fg_color=COLORS['btn_danger'],
            hover_color=COLORS['btn_danger_hover'],
            command=self.logout
        )
        self.logout_button.pack(side="right")
        
    def create_sidebar(self):
        """
        Create sidebar with navigation
        """
        self.sidebar = ctk.CTkFrame(
            self.main_content,
            fg_color=COLORS['sidebar_bg'],
            width=STYLES['sidebar_width']
        )
        self.sidebar.pack(side="left", fill="y", padx=(0, 20))
        self.sidebar.pack_propagate(False)
        
        # Sidebar content
        self.sidebar_content = ctk.CTkFrame(
            self.sidebar,
            fg_color="transparent"
        )
        self.sidebar_content.pack(fill="both", expand=True, padx=20, pady=30)
        
        # Navigation buttons
        self.nav_buttons = []
        
        # Patients button
        self.patients_btn = self.create_nav_button(
            self.sidebar_content,
            "👥 Gestion des Patients",
            self.show_patients
        )
        self.patients_btn.pack(fill="x", pady=(0, 10))
        
        # Appointments button
        self.appointments_btn = self.create_nav_button(
            self.sidebar_content,
            "📅 Gestion des RDV",
            self.show_appointments
        )
        self.appointments_btn.pack(fill="x", pady=(0, 10))
        
        # Statistics button
        self.stats_btn = self.create_nav_button(
            self.sidebar_content,
            "📊 Statistiques",
            self.show_statistics
        )
        self.stats_btn.pack(fill="x", pady=(0, 10))
        
        # Export button
        self.export_btn = self.create_nav_button(
            self.sidebar_content,
            "📤 Exporter",
            self.export_data
        )
        self.export_btn.pack(fill="x", pady=(0, 10))
        
    def create_nav_button(self, parent, text, command):
        """
        Create navigation button
        
        Args:
            parent: Parent widget
            text: Button text
            command: Command to execute
        
        Returns:
            Button widget
        """
        button = ctk.CTkButton(
            parent,
            text=text,
            font=("Segoe UI", 13, "bold"),
            height=45,
            corner_radius=8,
            fg_color=COLORS['sidebar_bg'],
            hover_color=COLORS['sidebar_hover'],
            text_color=COLORS['sidebar_text'],
            anchor="w",
            command=command
        )
        return button
        
    def create_content_area(self):
        """
        Create main content area
        """
        self.content_area = ctk.CTkFrame(
            self.main_content,
            fg_color=COLORS['white']
        )
        self.content_area.pack(fill="both", expand=True)
        
        # Patients tab (default)
        self.patients_tab = ctk.CTkFrame(self.content_area, fg_color="transparent")
        self.patients_tab.pack(fill="both", expand=True)
        
        # Create patients tab content
        self.create_patients_tab()
        
        # Appointments tab
        self.appointments_tab = ctk.CTkFrame(self.content_area, fg_color="transparent")
        
        # Statistics tab
        self.stats_tab = ctk.CTkFrame(self.content_area, fg_color="transparent")
        
    def create_patients_tab(self):
        """
        Create patients management tab
        """
        # Top controls
        self.patients_controls = ctk.CTkFrame(
            self.patients_tab,
            fg_color="transparent"
        )
        self.patients_controls.pack(fill="x", padx=20, pady=(20, 10))
        
        # Title
        self.patients_title = ctk.CTkLabel(
            self.patients_controls,
            text="Gestion des Patients",
            font=("Segoe UI", 20, "bold"),
            text_color=COLORS['text_primary']
        )
        self.patients_title.pack(side="left")
        
        # Buttons
        self.patients_buttons = ctk.CTkFrame(
            self.patients_controls,
            fg_color="transparent"
        )
        self.patients_buttons.pack(side="right")
        
        self.add_btn = ctk.CTkButton(
            self.patients_buttons,
            text="➕ Ajouter",
            font=("Segoe UI", 12, "bold"),
            height=35,
            width=120,
            fg_color=COLORS['btn_success'],
            hover_color=COLORS['btn_success_hover'],
            command=self.add_patient
        )
        self.add_btn.pack(side="left", padx=(0, 10))
        
        self.edit_btn = ctk.CTkButton(
            self.patients_buttons,
            text="✏️ Modifier",
            font=("Segoe UI", 12, "bold"),
            height=35,
            width=120,
            fg_color=COLORS['btn_primary'],
            hover_color=COLORS['btn_primary_hover'],
            command=self.edit_patient
        )
        self.edit_btn.pack(side="left", padx=(0, 10))
        
        self.delete_btn = ctk.CTkButton(
            self.patients_buttons,
            text="🗑️ Supprimer",
            font=("Segoe UI", 12, "bold"),
            height=35,
            width=120,
            fg_color=COLORS['btn_danger'],
            hover_color=COLORS['btn_danger_hover'],
            command=self.delete_patient
        )
        self.delete_btn.pack(side="left")
        
        # Search bar
        self.search_frame = ctk.CTkFrame(
            self.patients_tab,
            fg_color="transparent"
        )
        self.search_frame.pack(fill="x", padx=20, pady=(0, 10))
        
        self.search_entry = ctk.CTkEntry(
            self.search_frame,
            placeholder_text="Rechercher un patient...",
            font=("Segoe UI", 12),
            height=35,
            corner_radius=6,
            fg_color=COLORS['gray_light'],
            border_color=COLORS['gray'],
            border_width=1
        )
        self.search_entry.pack(side="left", fill="x", expand=True, padx=(0, 10))
        
        self.search_btn = ctk.CTkButton(
            self.search_frame,
            text="🔍 Rechercher",
            font=("Segoe UI", 12, "bold"),
            height=35,
            width=120,
            fg_color=COLORS['btn_primary'],
            hover_color=COLORS['btn_primary_hover'],
            command=self.search_patients
        )
        self.search_btn.pack(side="right")
        
        # Patients table
        self.patients_table_frame = ctk.CTkFrame(
            self.patients_tab,
            fg_color="transparent"
        )
        self.patients_table_frame.pack(fill="both", expand=True, padx=20, pady=(10, 20))
        
        # Treeview with scrollbar
        self.patients_tree = ttk.Treeview(
            self.patients_table_frame,
            columns=("ID", "Nom", "Prénom", "CIN", "Âge", "Téléphone", "Adresse"),
            show="headings",
            height=20
        )
        
        # Configure columns
        self.patients_tree.heading("ID", text="ID", anchor="center")
        self.patients_tree.heading("Nom", text="Nom", anchor="center")
        self.patients_tree.heading("Prénom", text="Prénom", anchor="center")
        self.patients_tree.heading("CIN", text="CIN", anchor="center")
        self.patients_tree.heading("Âge", text="Âge", anchor="center")
        self.patients_tree.heading("Téléphone", text="Téléphone", anchor="center")
        self.patients_tree.heading("Adresse", text="Adresse", anchor="center")
        
        self.patients_tree.column("ID", width=50, anchor="center", stretch=False)
        self.patients_tree.column("Nom", width=120, anchor="center")
        self.patients_tree.column("Prénom", width=120, anchor="center")
        self.patients_tree.column("CIN", width=100, anchor="center")
        self.patients_tree.column("Âge", width=60, anchor="center", stretch=False)
        self.patients_tree.column("Téléphone", width=120, anchor="center")
        self.patients_tree.column("Adresse", width=200, anchor="center")
        
        # Style the treeview
        style = ttk.Style()
        style.theme_use("default")
        style.configure("Treeview",
                       background=COLORS['white'],
                       foreground=COLORS['text_primary'],
                       rowheight=25,
                       fieldbackground=COLORS['white'])
        style.map('Treeview',
                 background=[('selected', COLORS['primary'])])
        
        # Scrollbar
        scrollbar = ttk.Scrollbar(
            self.patients_table_frame,
            orient="vertical",
            command=self.patients_tree.yview
        )
        self.patients_tree.configure(yscrollcommand=scrollbar.set)
        
        # Pack widgets
        self.patients_tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # Bind selection event
        self.patients_tree.bind("<<TreeviewSelect>>", self.on_patient_select)
        
    def create_appointments_tab(self):
        """
        Create appointments management tab
        """
        self.appointments_tab.pack(fill="both", expand=True)
        # Top controls
        self.appointments_controls = ctk.CTkFrame(
            self.appointments_tab,
            fg_color="transparent"
        )
        self.appointments_controls.pack(fill="x", padx=20, pady=(20, 10))
        
        # Title
        self.appointments_title = ctk.CTkLabel(
            self.appointments_controls,
            text="Gestion des Rendez-vous",
            font=("Segoe UI", 20, "bold"),
            text_color=COLORS['text_primary']
        )
        self.appointments_title.pack(side="left")
        
        # Buttons
        self.appointments_buttons = ctk.CTkFrame(
            self.appointments_controls,
            fg_color="transparent"
        )
        self.appointments_buttons.pack(side="right")
        
        self.add_appointment_btn = ctk.CTkButton(
            self.appointments_buttons,
            text="➕ Ajouter RDV",
            font=("Segoe UI", 12, "bold"),
            height=35,
            width=140,
            fg_color=COLORS['btn_success'],
            hover_color=COLORS['btn_success_hover'],
            command=self.add_appointment
        )
        self.add_appointment_btn.pack(side="left", padx=(0, 10))
        
        self.edit_appointment_btn = ctk.CTkButton(
            self.appointments_buttons,
            text="✏️ Modifier",
            font=("Segoe UI", 12, "bold"),
            height=35,
            width=120,
            fg_color=COLORS['btn_primary'],
            hover_color=COLORS['btn_primary_hover'],
            command=self.edit_appointment
        )
        self.edit_appointment_btn.pack(side="left", padx=(0, 10))
        
        self.delete_appointment_btn = ctk.CTkButton(
            self.appointments_buttons,
            text="🗑️ Supprimer",
            font=("Segoe UI", 12, "bold"),
            height=35,
            width=120,
            fg_color=COLORS['btn_danger'],
            hover_color=COLORS['btn_danger_hover'],
            command=self.delete_appointment
        )
        self.delete_appointment_btn.pack(side="left")
        
        # Appointments table
        self.appointments_table_frame = ctk.CTkFrame(
            self.appointments_tab,
            fg_color="transparent"
        )
        self.appointments_table_frame.pack(fill="both", expand=True, padx=20, pady=(10, 20))
        
        # Treeview with scrollbar
        self.appointments_tree = ttk.Treeview(
            self.appointments_table_frame,
            columns=("ID", "Patient", "Date", "Heure", "Type", "Status"),
            show="headings",
            height=20
        )
        
        # Configure columns
        self.appointments_tree.heading("ID", text="ID", anchor="center")
        self.appointments_tree.heading("Patient", text="Patient", anchor="center")
        self.appointments_tree.heading("Date", text="Date", anchor="center")
        self.appointments_tree.heading("Heure", text="Heure", anchor="center")
        self.appointments_tree.heading("Type", text="Type", anchor="center")
        self.appointments_tree.heading("Status", text="Status", anchor="center")
        
        self.appointments_tree.column("ID", width=50, anchor="center", stretch=False)
        self.appointments_tree.column("Patient", width=150, anchor="center")
        self.appointments_tree.column("Date", width=100, anchor="center")
        self.appointments_tree.column("Heure", width=80, anchor="center")
        self.appointments_tree.column("Type", width=120, anchor="center")
        self.appointments_tree.column("Status", width=100, anchor="center")
        
        # Style the treeview
        style = ttk.Style()
        style.theme_use("default")
        style.configure("Treeview",
                       background=COLORS['white'],
                       foreground=COLORS['text_primary'],
                       rowheight=25,
                       fieldbackground=COLORS['white'])
        style.map('Treeview',
                 background=[('selected', COLORS['primary'])])
        
        # Scrollbar
        scrollbar = ttk.Scrollbar(
            self.appointments_table_frame,
            orient="vertical",
            command=self.appointments_tree.yview
        )
        self.appointments_tree.configure(yscrollcommand=scrollbar.set)
        
        # Pack widgets
        self.appointments_tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
    def create_statistics_tab(self):
        """
        Create statistics tab
        """
        # Main frame
        self.stats_main = ctk.CTkFrame(
            self.stats_tab,
            fg_color="transparent"
        )
        self.stats_main.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Title
        self.stats_title = ctk.CTkLabel(
            self.stats_main,
            text="Statistiques",
            font=("Segoe UI", 24, "bold"),
            text_color=COLORS['text_primary']
        )
        self.stats_title.pack(pady=(0, 30))
        
        # Statistics cards
        self.stats_cards_frame = ctk.CTkFrame(
            self.stats_main,
            fg_color="transparent"
        )
        self.stats_cards_frame.pack(fill="x", padx=20)
        
        # Patients card
        self.patients_card = self.create_stat_card(
            self.stats_cards_frame,
            "Total Patients",
            "0",
            "👥"
        )
        self.patients_card.pack(side="left", padx=(0, 20))
        
        # Appointments today card
        self.appointments_today_card = self.create_stat_card(
            self.stats_cards_frame,
            "RDV Aujourd'hui",
            "0",
            "📅"
        )
        self.appointments_today_card.pack(side="left", padx=(0, 20))
        
        # Pending appointments card
        self.pending_card = self.create_stat_card(
            self.stats_cards_frame,
            "RDV en Attente",
            "0",
            "⏳"
        )
        self.pending_card.pack(side="left")
        
        # Notifications section
        self.notifications_frame = ctk.CTkFrame(
            self.stats_main,
            fg_color=COLORS['card_bg'],
            corner_radius=10,
            border_width=1,
            border_color=COLORS['card_border']
        )
        self.notifications_frame.pack(fill="x", padx=20, pady=(30, 0))
        
        self.notifications_title = ctk.CTkLabel(
            self.notifications_frame,
            text="🔔 Notifications",
            font=("Segoe UI", 16, "bold"),
            text_color=COLORS['text_primary']
        )
        self.notifications_title.pack(pady=(15, 10))
        
        self.notifications_text = ctk.CTkTextbox(
            self.notifications_frame,
            font=("Segoe UI", 12),
            height=200,
            fg_color=COLORS['white'],
            border_color=COLORS['gray'],
            border_width=1,
            state="disabled"
        )
        self.notifications_text.pack(fill="both", expand=True, padx=15, pady=(0, 15))
        
    def create_stat_card(self, parent, title, value, icon):
        """
        Create a statistics card
        
        Args:
            parent: Parent widget
            title: Card title
            value: Card value
            icon: Card icon
        
        Returns:
            Card frame
        """
        card = ctk.CTkFrame(
            parent,
            fg_color=COLORS['card_bg'],
            corner_radius=10,
            border_width=1,
            border_color=COLORS['card_border']
        )
        
        icon_label = ctk.CTkLabel(
            card,
            text=icon,
            font=("Segoe UI", 40),
            text_color=COLORS['primary']
        )
        icon_label.pack(pady=(15, 10))
        
        title_label = ctk.CTkLabel(
            card,
            text=title,
            font=("Segoe UI", 14, "bold"),
            text_color=COLORS['text_secondary']
        )
        title_label.pack(pady=(0, 10))
        
        value_label = ctk.CTkLabel(
            card,
            text=value,
            font=("Segoe UI", 32, "bold"),
            text_color=COLORS['primary']
        )
        value_label.pack(pady=(0, 15))
        
        return card
        
    def show_patients(self):
        """
        Show patients tab
        """
        self.patients_tab.pack(fill="both", expand=True)
        self.appointments_tab.pack_forget()
        self.stats_tab.pack_forget()
        
    def show_appointments(self):
        """
        Show appointments tab
        """
        self.patients_tab.pack_forget()
        self.appointments_tab.pack(fill="both", expand=True)
        self.stats_tab.pack_forget()
        
        # Create appointments tab content if not already created
        if self.appointments_tree is None:
            self.create_appointments_tab()
        
        # Load data
        self.load_appointments()
        
    def show_statistics(self):
        """
        Show statistics tab
        """
        self.patients_tab.pack_forget()
        self.appointments_tab.pack_forget()
        self.stats_tab.pack(fill="both", expand=True)
        
        # Create statistics tab content if not already created
        if not hasattr(self, 'patients_card'):
            self.create_statistics_tab()
        
        # Load data
        self.load_statistics()
        
    def load_patients(self):
        """
        Load patients data from database
        """
        # Clear existing data
        for item in self.patients_tree.get_children():
            self.patients_tree.delete(item)
        
        # Connect to database
        self.connection = self.db_config.connect()
        
        if not self.connection:
            messagebox.showerror("Erreur", "Impossible de se connecter à la base de données")
            return
        
        try:
            cursor = self.connection.cursor(dictionary=True)
            query = "SELECT * FROM patients ORDER BY nom, prenom"
            cursor.execute(query)
            patients = cursor.fetchall()
            
            # Insert data into treeview
            for patient in patients:
                self.patients_tree.insert(
                    "",
                    "end",
                    values=(
                        patient['id'],
                        patient['nom'],
                        patient['prenom'],
                        patient['cin'] or "N/A",
                        patient['age'] or "N/A",
                        patient['telephone'] or "N/A",
                        patient['adresse'] or "N/A"
                    ),
                    tags=(patient['id'],)
                )
                
        except Exception as e:
            messagebox.showerror("Erreur", f"Erreur lors du chargement des patients: {e}")
        
        finally:
            if cursor:
                cursor.close()
            if self.connection:
                self.db_config.close_connection(self.connection)
                self.connection = None
                
    def load_appointments(self):
        """
        Load appointments data from database
        """
        # Clear existing data
        if self.appointments_tree:
            for item in self.appointments_tree.get_children():
                self.appointments_tree.delete(item)
        
        # Connect to database
        self.connection = self.db_config.connect()
        
        if not self.connection:
            messagebox.showerror("Erreur", "Impossible de se connecter à la base de données")
            return
        
        try:
            cursor = self.connection.cursor(dictionary=True)
            query = """
                SELECT r.*, p.nom, p.prenom 
                FROM rendezvous r
                JOIN patients p ON r.patient_id = p.id
                ORDER BY r.date, r.heure
            """
            cursor.execute(query)
            appointments = cursor.fetchall()
            
            # Insert data into treeview
            if self.appointments_tree:
                for appointment in appointments:
                    patient_name = f"{appointment['nom']} {appointment['prenom']}"
                    self.appointments_tree.insert(
                    "",
                    "end",
                    values=(
                        appointment['id'],
                        patient_name,
                        appointment['date'].strftime("%d/%m/%Y"),
                        appointment['heure'],
                        appointment['type'] or "N/A",
                        appointment['status'].capitalize()
                    ),
                    tags=(appointment['id'],)
                )
                
        except Exception as e:
            messagebox.showerror("Erreur", f"Erreur lors du chargement des rendez-vous: {e}")
        
        finally:
            if cursor:
                cursor.close()
            if self.connection:
                self.db_config.close_connection(self.connection)
                self.connection = None
                
    def load_statistics(self):
        """
        Load and display statistics
        """
        # Connect to database
        self.connection = self.db_config.connect()
        
        if not self.connection:
            return
        
        try:
            cursor = self.connection.cursor(dictionary=True)
            
            # Total patients
            cursor.execute("SELECT COUNT(*) as count FROM patients")
            total_patients = cursor.fetchone()['count']
            
            # Appointments today
            today = datetime.now().strftime("%Y-%m-%d")
            cursor.execute("SELECT COUNT(*) as count FROM rendezvous WHERE date = %s", (today,))
            appointments_today = cursor.fetchone()['count']
            
            # Pending appointments
            cursor.execute("SELECT COUNT(*) as count FROM rendezvous WHERE status = 'pending'")
            pending_appointments = cursor.fetchone()['count']
            
            # Update cards
            if hasattr(self, 'patients_card'):
                self.patients_card.winfo_children()[2].configure(text=str(total_patients))
                self.appointments_today_card.winfo_children()[2].configure(text=str(appointments_today))
                self.pending_card.winfo_children()[2].configure(text=str(pending_appointments))
            
            # Load notifications
            cursor.execute("""
                SELECT r.*, p.nom, p.prenom 
                FROM rendezvous r
                JOIN patients p ON r.patient_id = p.id
                WHERE r.date >= %s
                ORDER BY r.date, r.heure
                LIMIT 5
            """, (today,))
            
            notifications = cursor.fetchall()
            
            # Display notifications
            self.notifications_text.configure(state="normal")
            self.notifications_text.delete("1.0", "end")
            
            if notifications:
                for notif in notifications:
                    patient_name = f"{notif['nom']} {notif['prenom']}"
                    date_str = notif['date'].strftime("%d/%m/%Y")
                    self.notifications_text.insert(
                        "end",
                        f"• {patient_name} - {date_str} à {notif['heure']} ({notif['status'].capitalize()})\n"
                    )
            else:
                self.notifications_text.insert("end", "Aucune notification disponible.")
                
            self.notifications_text.configure(state="disabled")
            
        except Exception as e:
            print(f"Erreur lors du chargement des statistiques: {e}")
        
        finally:
            if cursor:
                cursor.close()
            if self.connection:
                self.db_config.close_connection(self.connection)
                self.connection = None
                
    def on_patient_select(self, event):
        """
        Handle patient selection
        
        Args:
            event: Selection event
        """
        selected_items = self.patients_tree.selection()
        
        if selected_items:
            item = selected_items[0]
            patient_id = self.patients_tree.item(item, "tags")[0]
            self.selected_patient_id = patient_id
            
    def add_patient(self):
        """
        Add new patient
        """
        PatientForm(self, self.db_config, mode="add")
        
    def edit_patient(self):
        """
        Edit selected patient
        """
        if not self.selected_patient_id:
            messagebox.showwarning("Avertissement", "Veuillez sélectionner un patient")
            return
        
        PatientForm(self, self.db_config, mode="edit", patient_id=self.selected_patient_id)
        
    def delete_patient(self):
        """
        Delete selected patient
        """
        if not self.selected_patient_id:
            messagebox.showwarning("Avertissement", "Veuillez sélectionner un patient")
            return
        
        if messagebox.askyesno("Confirmation", "Êtes-vous sûr de vouloir supprimer ce patient?"):
            # Connect to database
            self.connection = self.db_config.connect()
            
            if not self.connection:
                messagebox.showerror("Erreur", "Impossible de se connecter à la base de données")
                return
            
            try:
                cursor = self.connection.cursor()
                query = "DELETE FROM patients WHERE id = %s"
                cursor.execute(query, (self.selected_patient_id,))
                self.connection.commit()
                
                messagebox.showinfo("Succès", "Patient supprimé avec succès")
                self.load_patients()
                self.selected_patient_id = None
                
            except Exception as e:
                messagebox.showerror("Erreur", f"Erreur lors de la suppression: {e}")
            
            finally:
                if cursor:
                    cursor.close()
                if self.connection:
                    self.db_config.close_connection(self.connection)
                    self.connection = None
                    
    def search_patients(self):
        """
        Search patients by name
        """
        search_term = self.search_entry.get().strip().lower()
        
        if not search_term:
            self.load_patients()
            return
        
        # Clear existing data
        for item in self.patients_tree.get_children():
            self.patients_tree.delete(item)
        
        # Connect to database
        self.connection = self.db_config.connect()
        
        if not self.connection:
            messagebox.showerror("Erreur", "Impossible de se connecter à la base de données")
            return
        
        try:
            cursor = self.connection.cursor(dictionary=True)
            query = """
                SELECT * FROM patients 
                WHERE LOWER(nom) LIKE %s OR LOWER(prenom) LIKE %s
                ORDER BY nom, prenom
            """
            cursor.execute(query, (f"%{search_term}%", f"%{search_term}%"))
            patients = cursor.fetchall()
            
            # Insert data into treeview
            for patient in patients:
                self.patients_tree.insert(
                    "",
                    "end",
                    values=(
                        patient['id'],
                        patient['nom'],
                        patient['prenom'],
                        patient['cin'] or "N/A",
                        patient['age'] or "N/A",
                        patient['telephone'] or "N/A",
                        patient['adresse'] or "N/A"
                    ),
                    tags=(patient['id'],)
                )
                
        except Exception as e:
            messagebox.showerror("Erreur", f"Erreur lors de la recherche: {e}")
        
        finally:
            if cursor:
                cursor.close()
            if self.connection:
                self.db_config.close_connection(self.connection)
                self.connection = None
                
    def add_appointment(self):
        """
        Add new appointment
        """
        AppointmentForm(self, self.db_config, mode="add")
        
    def edit_appointment(self):
        """
        Edit selected appointment
        """
        selected_items = self.appointments_tree.selection()
        
        if not selected_items:
            messagebox.showwarning("Avertissement", "Veuillez sélectionner un rendez-vous")
            return
        
        item = selected_items[0]
        appointment_id = self.appointments_tree.item(item, "tags")[0]
        
        AppointmentForm(self, self.db_config, mode="edit", appointment_id=appointment_id)
        
    def delete_appointment(self):
        """
        Delete selected appointment
        """
        selected_items = self.appointments_tree.selection()
        
        if not selected_items:
            messagebox.showwarning("Avertissement", "Veuillez sélectionner un rendez-vous")
            return
        
        item = selected_items[0]
        appointment_id = self.appointments_tree.item(item, "tags")[0]
        
        if messagebox.askyesno("Confirmation", "Êtes-vous sûr de vouloir supprimer ce rendez-vous?"):
            # Connect to database
            self.connection = self.db_config.connect()
            
            if not self.connection:
                messagebox.showerror("Erreur", "Impossible de se connecter à la base de données")
                return
            
            try:
                cursor = self.connection.cursor()
                query = "DELETE FROM rendezvous WHERE id = %s"
                cursor.execute(query, (appointment_id,))
                self.connection.commit()
                
                messagebox.showinfo("Succès", "Rendez-vous supprimé avec succès")
                self.load_appointments()
                
            except Exception as e:
                messagebox.showerror("Erreur", f"Erreur lors de la suppression: {e}")
            
            finally:
                if cursor:
                    cursor.close()
                if self.connection:
                    self.db_config.close_connection(self.connection)
                    self.connection = None
                    
    def export_data(self):
        """
        Export patients data to CSV
        """
        ExportUtils.export_patients_to_csv(self.db_config)
        
    def logout(self):
        """
        Logout and return to login
        """
        self.destroy()
        from login import LoginWindow
        login = LoginWindow()
        login.mainloop()


if __name__ == "__main__":
    # For testing purposes
    from login import LoginWindow
    login = LoginWindow()
    login.mainloop()
