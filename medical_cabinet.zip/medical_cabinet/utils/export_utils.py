"""
Export Utilities
Functions for exporting data to CSV and PDF
"""

import csv
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image
from reportlab.lib.units import inch
from datetime import datetime
import mysql.connector
from config.db_config import DatabaseConfig

class ExportUtils:
    """
    Export utilities class
    """
    
    @staticmethod
    def export_patients_to_csv(db_config):
        """
        Export patients data to CSV file
        
        Args:
            db_config: Database configuration object
        """
        # Connect to database
        connection = db_config.connect()
        
        if not connection:
            return
        
        try:
            cursor = connection.cursor(dictionary=True)
            query = "SELECT * FROM patients ORDER BY nom, prenom"
            cursor.execute(query)
            patients = cursor.fetchall()
            
            # Generate filename
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"patients_export_{timestamp}.csv"
            
            # Write to CSV
            with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
                fieldnames = ['ID', 'Nom', 'Prénom', 'CIN', 'Âge', 'Téléphone', 'Adresse', 'Date Création']
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                
                writer.writeheader()
                
                for patient in patients:
                    writer.writerow({
                        'ID': patient['id'],
                        'Nom': patient['nom'],
                        'Prénom': patient['prenom'],
                        'CIN': patient['cin'] or '',
                        'Âge': patient['age'] or '',
                        'Téléphone': patient['telephone'] or '',
                        'Adresse': patient['adresse'] or '',
                        'Date Création': patient['created_at'].strftime('%d/%m/%Y %H:%M') if patient['created_at'] else ''
                    })
                    
            print(f"✅ Patients exported to {filename}")
            
        except Exception as e:
            print(f"❌ Error exporting patients: {e}")
        
        finally:
            if cursor:
                cursor.close()
            if connection:
                db_config.close_connection(connection)
                
    @staticmethod
    def export_diagnostic_to_pdf(patient_info, diagnostic_text, doctor_name):
        """
        Export single diagnostic to PDF
        
        Args:
            patient_info: Patient information dictionary
            diagnostic_text: Diagnostic text
            doctor_name: Doctor's username
            
        Returns:
            tuple: (success: bool, filename: str, error_message: str)
        """
        try:
            # Generate filename
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"diagnostic_{patient_info['id']}_{timestamp}.pdf"
            
            # Create PDF document
            doc = SimpleDocTemplate(filename, pagesize=A4)
            elements = []
            
            # Styles
            styles = getSampleStyleSheet()
            
            # Header
            header_style = ParagraphStyle(
                'CustomHeader',
                parent=styles['Heading1'],
                fontSize=24,
                textColor=colors.HexColor('#1E88E5'),
                spaceAfter=30,
                alignment=1  # Center
            )
            
            elements.append(Paragraph("Dossier Médical", header_style))
            
            # Patient information
            patient_style = ParagraphStyle(
                'PatientInfo',
                parent=styles['Normal'],
                fontSize=12,
                textColor=colors.HexColor('#212121'),
                spaceAfter=20
            )
            
            patient_name = f"<b>Nom et Prénom:</b> {patient_info['nom']} {patient_info['prenom']}"
            patient_cin = f"<b>CIN:</b> {patient_info['cin'] or 'N/A'}"
            patient_age = f"<b>Âge:</b> {patient_info['age'] or 'N/A'}"
            patient_phone = f"<b>Téléphone:</b> {patient_info['telephone'] or 'N/A'}"
            
            elements.append(Paragraph(patient_name, patient_style))
            elements.append(Paragraph(patient_cin, patient_style))
            elements.append(Paragraph(patient_age, patient_style))
            elements.append(Paragraph(patient_phone, patient_style))
            
            # Diagnostic
            diagnostic_style = ParagraphStyle(
                'Diagnostic',
                parent=styles['Normal'],
                fontSize=12,
                textColor=colors.HexColor('#212121'),
                spaceAfter=20
            )
            
            elements.append(Paragraph("<b>Diagnostic:</b>", diagnostic_style))
            elements.append(Paragraph(diagnostic_text.replace('\n', '<br/>'), diagnostic_style))
            
            # Doctor information
            doctor_style = ParagraphStyle(
                'DoctorInfo',
                parent=styles['Normal'],
                fontSize=12,
                textColor=colors.HexColor('#1E88E5'),
                spaceAfter=20
            )
            
            elements.append(Paragraph(f"<b>Docteur:</b> {doctor_name}", doctor_style))
            
            # Date
            date_style = ParagraphStyle(
                'DateInfo',
                parent=styles['Normal'],
                fontSize=10,
                textColor=colors.HexColor('#757575'),
                alignment=2  # Right
            )
            
            current_date = datetime.now().strftime("%d/%m/%Y %H:%M")
            elements.append(Paragraph(f"Date: {current_date}", date_style))
            
            # Build PDF
            doc.build(elements)
            
            print(f"✅ Diagnostic exported to {filename}")
            return (True, filename, None)
            
        except Exception as e:
            error_msg = f"Erreur lors de l'exportation PDF: {str(e)}"
            print(f"❌ {error_msg}")
            return (False, None, error_msg)
        
    @staticmethod
    def export_all_diagnostics_to_pdf(db_config):
        """
        Export all diagnostics to PDF
        
        Args:
            db_config: Database configuration object
        """
        # Connect to database
        connection = db_config.connect()
        
        if not connection:
            return
        
        try:
            cursor = connection.cursor(dictionary=True)
            
            # Get all diagnostics with patient and doctor info
            query = """
                SELECT d.*, p.nom, p.prenom, p.cin, u.username as doctor_name
                FROM diagnostics d
                JOIN patients p ON d.patient_id = p.id
                JOIN users u ON d.doctor_id = u.id
                ORDER BY d.date_diagnostic DESC, d.id DESC
            """
            cursor.execute(query)
            diagnostics = cursor.fetchall()
            
            # Generate filename
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"all_diagnostics_export_{timestamp}.pdf"
            
            # Create PDF document
            doc = SimpleDocTemplate(filename, pagesize=A4)
            elements = []
            
            # Styles
            styles = getSampleStyleSheet()
            
            # Header
            header_style = ParagraphStyle(
                'CustomHeader',
                parent=styles['Heading1'],
                fontSize=24,
                textColor=colors.HexColor('#1E88E5'),
                spaceAfter=30,
                alignment=1  # Center
            )
            
            elements.append(Paragraph("Tous les Diagnostics", header_style))
            
            # Date
            date_style = ParagraphStyle(
                'DateInfo',
                parent=styles['Normal'],
                fontSize=10,
                textColor=colors.HexColor('#757575'),
                alignment=2,  # Right
                spaceAfter=30
            )
            
            current_date = datetime.now().strftime("%d/%m/%Y %H:%M")
            elements.append(Paragraph(f"Date d'export: {current_date}", date_style))
            
            # Diagnostics table
            table_data = [
                ['ID', 'Patient', 'Date', 'Diagnostic', 'Docteur']
            ]
            
            for diagnostic in diagnostics:
                patient_name = f"{diagnostic['nom']} {diagnostic['prenom']}"
                date_str = diagnostic['date_diagnostic'].strftime('%d/%m/%Y')
                table_data.append([
                    str(diagnostic['id']),
                    patient_name,
                    date_str,
                    diagnostic['diagnostic'][:100] + '...' if len(diagnostic['diagnostic']) > 100 else diagnostic['diagnostic'],
                    diagnostic['doctor_name']
                ])
                
            # Create table
            table = Table(table_data, colWidths=[40, 150, 80, 300, 80])
            
            table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1E88E5')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 10),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), colors.white),
                ('TEXTCOLOR', (0, 1), (-1, -1), colors.HexColor('#212121')),
                ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 1), (-1, -1), 9),
                ('TOPPADDING', (0, 1), (-1, -1), 6),
                ('BOTTOMPADDING', (0, 1), (-1, -1), 6),
                ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#E0E0E0')),
            ]))
            
            elements.append(table)
            
            # Build PDF
            doc.build(elements)
            
            print(f"✅ All diagnostics exported to {filename}")
            
        except Exception as e:
            print(f"❌ Error exporting diagnostics: {e}")
        
        finally:
            if cursor:
                cursor.close()
            if connection:
                db_config.close_connection(connection)
                
    @staticmethod
    def export_appointments_to_pdf(db_config):
        """
        Export all appointments to PDF
        
        Args:
            db_config: Database configuration object
        """
        # Connect to database
        connection = db_config.connect()
        
        if not connection:
            return
        
        try:
            cursor = connection.cursor(dictionary=True)
            
            # Get all appointments with patient info
            query = """
                SELECT r.*, p.nom, p.prenom
                FROM rendezvous r
                JOIN patients p ON r.patient_id = p.id
                ORDER BY r.date, r.heure
            """
            cursor.execute(query)
            appointments = cursor.fetchall()
            
            # Generate filename
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"appointments_export_{timestamp}.pdf"
            
            # Create PDF document
            doc = SimpleDocTemplate(filename, pagesize=A4)
            elements = []
            
            # Styles
            styles = getSampleStyleSheet()
            
            # Header
            header_style = ParagraphStyle(
                'CustomHeader',
                parent=styles['Heading1'],
                fontSize=24,
                textColor=colors.HexColor('#1E88E5'),
                spaceAfter=30,
                alignment=1  # Center
            )
            
            elements.append(Paragraph("Tous les Rendez-vous", header_style))
            
            # Date
            date_style = ParagraphStyle(
                'DateInfo',
                parent=styles['Normal'],
                fontSize=10,
                textColor=colors.HexColor('#757575'),
                alignment=2,  # Right
                spaceAfter=30
            )
            
            current_date = datetime.now().strftime("%d/%m/%Y %H:%M")
            elements.append(Paragraph(f"Date d'export: {current_date}", date_style))
            
            # Appointments table
            table_data = [
                ['ID', 'Patient', 'Date', 'Heure', 'Type', 'Status']
            ]
            
            for appointment in appointments:
                patient_name = f"{appointment['nom']} {appointment['prenom']}"
                date_str = appointment['date'].strftime('%d/%m/%Y')
                table_data.append([
                    str(appointment['id']),
                    patient_name,
                    date_str,
                    appointment['heure'],
                    appointment['type'] or 'N/A',
                    appointment['status'].capitalize()
                ])
                
            # Create table
            table = Table(table_data, colWidths=[40, 150, 80, 60, 100, 80])
            
            table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1E88E5')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
                ('ALIGN', (0, 0), (-1, 0), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 10),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), colors.white),
                ('TEXTCOLOR', (0, 1), (-1, -1), colors.HexColor('#212121')),
                ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 1), (-1, -1), 9),
                ('TOPPADDING', (0, 1), (-1, -1), 6),
                ('BOTTOMPADDING', (0, 1), (-1, -1), 6),
                ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#E0E0E0')),
            ]))
            
            elements.append(table)
            
            # Build PDF
            doc.build(elements)
            
            print(f"✅ All appointments exported to {filename}")
            
        except Exception as e:
            print(f"❌ Error exporting appointments: {e}")
        
        finally:
            if cursor:
                cursor.close()
            if connection:
                db_config.close_connection(connection)
                
    @staticmethod
    def export_patients_to_pdf(db_config):
        """
        Export all patients to PDF
        
        Args:
            db_config: Database configuration object
        """
        # Connect to database
        connection = db_config.connect()
        
        if not connection:
            return
        
        try:
            cursor = connection.cursor(dictionary=True)
            query = "SELECT * FROM patients ORDER BY nom, prenom"
            cursor.execute(query)
            patients = cursor.fetchall()
            
            # Generate filename
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"patients_export_{timestamp}.pdf"
            
            # Create PDF document
            doc = SimpleDocTemplate(filename, pagesize=A4)
            elements = []
            
            # Styles
            styles = getSampleStyleSheet()
            
            # Header
            header_style = ParagraphStyle(
                'CustomHeader',
                parent=styles['Heading1'],
                fontSize=24,
                textColor=colors.HexColor('#1E88E5'),
                spaceAfter=30,
                alignment=1  # Center
            )
            
            elements.append(Paragraph("Tous les Patients", header_style))
            
            # Date
            date_style = ParagraphStyle(
                'DateInfo',
                parent=styles['Normal'],
                fontSize=10,
                textColor=colors.HexColor('#757575'),
                alignment=2,  # Right
                spaceAfter=30
            )
            
            current_date = datetime.now().strftime("%d/%m/%Y %H:%M")
            elements.append(Paragraph(f"Date d'export: {current_date}", date_style))
            
            # Patients table
            table_data = [
                ['ID', 'Nom', 'Prénom', 'CIN', 'Âge', 'Téléphone', 'Adresse']
            ]
            
            for patient in patients:
                table_data.append([
                    str(patient['id']),
                    patient['nom'],
                    patient['prenom'],
                    patient['cin'] or 'N/A',
                    str(patient['age']) if patient['age'] else 'N/A',
                    patient['telephone'] or 'N/A',
                    patient['adresse'] or 'N/A'
                ])
                
            # Create table
            table = Table(table_data, colWidths=[40, 120, 120, 100, 60, 120, 200])
            
            table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1E88E5')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
                ('ALIGN', (0, 0), (-1, 0), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 10),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), colors.white),
                ('TEXTCOLOR', (0, 1), (-1, -1), colors.HexColor('#212121')),
                ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 1), (-1, -1), 9),
                ('TOPPADDING', (0, 1), (-1, -1), 6),
                ('BOTTOMPADDING', (0, 1), (-1, -1), 6),
                ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#E0E0E0')),
            ]))
            
            elements.append(table)
            
            # Build PDF
            doc.build(elements)
            
            print(f"✅ All patients exported to {filename}")
            
        except Exception as e:
            print(f"❌ Error exporting patients: {e}")
        
        finally:
            if cursor:
                cursor.close()
            if connection:
                db_config.close_connection(connection)
                
    @staticmethod
    def export_statistics_to_pdf(db_config):
        """
        Export statistics to PDF
        
        Args:
            db_config: Database configuration object
        """
        # Connect to database
        connection = db_config.connect()
        
        if not connection:
            return
        
        try:
            cursor = connection.cursor(dictionary=True)
            
            # Get statistics
            cursor.execute("SELECT COUNT(*) as count FROM patients")
            total_patients = cursor.fetchone()['count']
            
            cursor.execute("SELECT COUNT(*) as count FROM rendezvous")
            total_appointments = cursor.fetchone()['count']
            
            cursor.execute("SELECT COUNT(*) as count FROM diagnostics")
            total_diagnostics = cursor.fetchone()['count']
            
            today = datetime.now().strftime("%Y-%m-%d")
            cursor.execute("SELECT COUNT(*) as count FROM rendezvous WHERE date = %s", (today,))
            appointments_today = cursor.fetchone()['count']
            
            cursor.execute("SELECT COUNT(*) as count FROM diagnostics WHERE date_diagnostic = %s", (today,))
            diagnostics_today = cursor.fetchone()['count']
            
            cursor.execute("SELECT COUNT(*) as count FROM rendezvous WHERE status = 'pending'")
            pending_appointments = cursor.fetchone()['count']
            
            # Generate filename
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"statistics_export_{timestamp}.pdf"
            
            # Create PDF document
            doc = SimpleDocTemplate(filename, pagesize=A4)
            elements = []
            
            # Styles
            styles = getSampleStyleSheet()
            
            # Header
            header_style = ParagraphStyle(
                'CustomHeader',
                parent=styles['Heading1'],
                fontSize=24,
                textColor=colors.HexColor('#1E88E5'),
                spaceAfter=30,
                alignment=1  # Center
            )
            
            elements.append(Paragraph("Statistiques", header_style))
            
            # Date
            date_style = ParagraphStyle(
                'DateInfo',
                parent=styles['Normal'],
                fontSize=10,
                textColor=colors.HexColor('#757575'),
                alignment=2,  # Right
                spaceAfter=30
            )
            
            current_date = datetime.now().strftime("%d/%m/%Y %H:%M")
            elements.append(Paragraph(f"Date: {current_date}", date_style))
            
            # Statistics table
            table_data = [
                ['Statistique', 'Valeur'],
                ['Total Patients', str(total_patients)],
                ['Total Rendez-vous', str(total_appointments)],
                ['Total Diagnostics', str(total_diagnostics)],
                ['Rendez-vous Aujourd\'hui', str(appointments_today)],
                ['Diagnostics Aujourd\'hui', str(diagnostics_today)],
                ['Rendez-vous en Attente', str(pending_appointments)]
            ]
            
            # Create table
            table = Table(table_data, colWidths=[200, 100])
            
            table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1E88E5')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
                ('ALIGN', (0, 0), (-1, 0), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 12),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), colors.white),
                ('TEXTCOLOR', (0, 1), (-1, -1), colors.HexColor('#212121')),
                ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 1), (-1, -1), 11),
                ('TOPPADDING', (0, 1), (-1, -1), 10),
                ('BOTTOMPADDING', (0, 1), (-1, -1), 10),
                ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#E0E0E0')),
            ]))
            
            elements.append(table)
            
            # Build PDF
            doc.build(elements)
            
            print(f"✅ Statistics exported to {filename}")
            
        except Exception as e:
            print(f"❌ Error exporting statistics: {e}")
        
        finally:
            if cursor:
                cursor.close()
            if connection:
                db_config.close_connection(connection)
                
    @staticmethod
    def export_all_to_pdf(db_config):
        """
        Export all data to PDF
        
        Args:
            db_config: Database configuration object
        """
        print("Exporting all data...")
        ExportUtils.export_patients_to_pdf(db_config)
        ExportUtils.export_appointments_to_pdf(db_config)
        ExportUtils.export_all_diagnostics_to_pdf(db_config)
        ExportUtils.export_statistics_to_pdf(db_config)
        print("✅ All data exported successfully")
