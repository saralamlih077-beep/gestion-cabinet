"""
Appointment Form
Modal window for adding/editing appointments
"""

import customtkinter as ctk
from tkinter import messagebox
from tkcalendar import DateEntry
from datetime import datetime

class AppointmentForm(ctk.CTkToplevel):
    """
    Appointment form modal window
    """
    
    def __init__(self, parent, db_config, mode="add", appointment_id=None):
        super().__init__(parent)
        
        # Configure window
        self.title("Rendez-vous" if mode == "add" else "Modifier RDV")
        self.geometry("500x550")
        self.resizable(False, False)
        
        # Set modal
        self.transient(parent)
        self.grab_set()
        
        # Initialize
        self.parent = parent
        self.db_config = db_config
        self.mode = mode
        self.appointment_id = appointment_id
        self.connection = None
        
        # Create UI
        self.create_widgets()
        
        # Load appointment data if editing
        if mode == "edit" and appointment_id:
            self.load_appointment_data()
        
    def create_widgets(self):
        """
        Create form widgets
        """
        # Main frame
        self.main_frame = ctk.CTkFrame(
            self,
            fg_color="white"
        )
        self.main_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Title
        self.title_label = ctk.CTkLabel(
            self.main_frame,
            text="Ajouter un Rendez-vous" if self.mode == "add" else "Modifier Rendez-vous",
            font=("Segoe UI", 20, "bold"),
            text_color="#1E88E5"
        )
        self.title_label.pack(pady=(0, 20))
        
        # Form fields
        self.form_frame = ctk.CTkScrollableFrame(
            self.main_frame,
            fg_color="transparent"
        )
        self.form_frame.pack(fill="both", expand=True)
        
        # Patient selection
        self.patient_label = ctk.CTkLabel(
            self.form_frame,
            text="Patient *",
            font=("Segoe UI", 12, "bold"),
            text_color="#212121",
            anchor="w"
        )
        self.patient_label.pack(fill="x", pady=(0, 5))
        
        self.patient_var = ctk.StringVar()
        self.patient_combobox = ctk.CTkComboBox(
            self.form_frame,
            variable=self.patient_var,
            font=("Segoe UI", 12),
            height=35,
            corner_radius=6,
            fg_color="#F5F5F5",
            border_color="#E0E0E0",
            border_width=1,
            state="readonly"
        )
        self.patient_combobox.pack(fill="x", pady=(0, 15))
        
        # Load patients
        self.load_patients()
        
        # Date
        self.date_label = ctk.CTkLabel(
            self.form_frame,
            text="Date *",
            font=("Segoe UI", 12, "bold"),
            text_color="#212121",
            anchor="w"
        )
        self.date_label.pack(fill="x", pady=(0, 5))
        
        self.date_entry = DateEntry(
            self.form_frame,
            date_pattern='dd/mm/yyyy',
            font=("Segoe UI", 12),
            background="#1E88E5",
            foreground="white",
            borderwidth=2,
            width=20
        )
        self.date_entry.pack(fill="x", pady=(0, 15))
        
        # Heure
        self.heure_label = ctk.CTkLabel(
            self.form_frame,
            text="Heure *",
            font=("Segoe UI", 12, "bold"),
            text_color="#212121",
            anchor="w"
        )
        self.heure_label.pack(fill="x", pady=(0, 5))
        
        self.heure_entry = ctk.CTkEntry(
            self.form_frame,
            placeholder_text="Ex: 14:30",
            font=("Segoe UI", 12),
            height=35,
            corner_radius=6,
            fg_color="#F5F5F5",
            border_color="#E0E0E0",
            border_width=1
        )
        self.heure_entry.pack(fill="x", pady=(0, 15))
        
        # Type
        self.type_label = ctk.CTkLabel(
            self.form_frame,
            text="Type",
            font=("Segoe UI", 12, "bold"),
            text_color="#212121",
            anchor="w"
        )
        self.type_label.pack(fill="x", pady=(0, 5))
        
        self.type_entry = ctk.CTkEntry(
            self.form_frame,
            placeholder_text="Type de rendez-vous",
            font=("Segoe UI", 12),
            height=35,
            corner_radius=6,
            fg_color="#F5F5F5",
            border_color="#E0E0E0",
            border_width=1
        )
        self.type_entry.pack(fill="x", pady=(0, 15))
        
        # Status
        self.status_label = ctk.CTkLabel(
            self.form_frame,
            text="Status",
            font=("Segoe UI", 12, "bold"),
            text_color="#212121",
            anchor="w"
        )
        self.status_label.pack(fill="x", pady=(0, 5))
        
        self.status_var = ctk.StringVar(value="pending")
        self.status_frame = ctk.CTkFrame(
            self.form_frame,
            fg_color="transparent"
        )
        self.status_frame.pack(fill="x", pady=(0, 15))
        
        self.pending_radio = ctk.CTkRadioButton(
            self.status_frame,
            text="En attente",
            variable=self.status_var,
            value="pending",
            font=("Segoe UI", 12),
            fg_color="#1E88E5",
            hover_color="#1565C0"
        )
        self.pending_radio.pack(side="left", padx=(0, 15))
        
        self.confirmed_radio = ctk.CTkRadioButton(
            self.status_frame,
            text="Confirmé",
            variable=self.status_var,
            value="confirmed",
            font=("Segoe UI", 12),
            fg_color="#1E88E5",
            hover_color="#1565C0"
        )
        self.confirmed_radio.pack(side="left", padx=(0, 15))
        
        self.completed_radio = ctk.CTkRadioButton(
            self.status_frame,
            text="Terminé",
            variable=self.status_var,
            value="completed",
            font=("Segoe UI", 12),
            fg_color="#1E88E5",
            hover_color="#1565C0"
        )
        self.completed_radio.pack(side="left")
        
        # Buttons
        self.button_frame = ctk.CTkFrame(
            self.main_frame,
            fg_color="transparent"
        )
        self.button_frame.pack(fill="x", pady=(10, 0))
        
        self.cancel_btn = ctk.CTkButton(
            self.button_frame,
            text="Annuler",
            font=("Segoe UI", 12, "bold"),
            height=35,
            width=120,
            fg_color="#F44336",
            hover_color="#D32F2F",
            command=self.destroy
        )
        self.cancel_btn.pack(side="right", padx=(10, 0))
        
        self.save_btn = ctk.CTkButton(
            self.button_frame,
            text="Enregistrer" if self.mode == "add" else "Modifier",
            font=("Segoe UI", 12, "bold"),
            height=35,
            width=120,
            fg_color="#1E88E5",
            hover_color="#1565C0",
            command=self.save_appointment
        )
        self.save_btn.pack(side="right")
        
    def load_patients(self):
        """
        Load patients into combobox
        """
        # Connect to database
        self.connection = self.db_config.connect()
        
        if not self.connection:
            messagebox.showerror("Erreur", "Impossible de se connecter à la base de données")
            self.destroy()
            return
        
        try:
            cursor = self.connection.cursor(dictionary=True)
            query = "SELECT id, nom, prenom FROM patients ORDER BY nom, prenom"
            cursor.execute(query)
            patients = cursor.fetchall()
            
            # Create patient options
            patient_options = []
            self.patient_id_map = {}
            
            for patient in patients:
                patient_name = f"{patient['nom']} {patient['prenom']}"
                patient_options.append(patient_name)
                self.patient_id_map[patient_name] = patient['id']
            
            self.patient_combobox.configure(values=patient_options)
            
            if patient_options:
                self.patient_combobox.set(patient_options[0])
                
        except Exception as e:
            messagebox.showerror("Erreur", f"Erreur lors du chargement des patients: {e}")
            self.destroy()
        
        finally:
            if cursor:
                cursor.close()
            if self.connection:
                self.db_config.close_connection(self.connection)
                self.connection = None
                
    def load_appointment_data(self):
        """
        Load appointment data for editing
        """
        # Connect to database
        self.connection = self.db_config.connect()
        
        if not self.connection:
            messagebox.showerror("Erreur", "Impossible de se connecter à la base de données")
            self.destroy()
            return
        
        try:
            cursor = self.connection.cursor(dictionary=True)
            query = """
                SELECT r.*, p.nom, p.prenom 
                FROM rendezvous r
                JOIN patients p ON r.patient_id = p.id
                WHERE r.id = %s
            """
            cursor.execute(query, (self.appointment_id,))
            appointment = cursor.fetchone()
            
            if appointment:
                # Set patient
                patient_name = f"{appointment['nom']} {appointment['prenom']}"
                self.patient_combobox.set(patient_name)
                
                # Set date
                self.date_entry.set_date(appointment['date'])
                
                # Set time
                self.heure_entry.insert(0, appointment['heure'])
                
                # Set type
                self.type_entry.insert(0, appointment['type'] or "")
                
                # Set status
                self.status_var.set(appointment['status'])
            else:
                messagebox.showerror("Erreur", "Rendez-vous non trouvé")
                self.destroy()
                
        except Exception as e:
            messagebox.showerror("Erreur", f"Erreur lors du chargement: {e}")
            self.destroy()
        
        finally:
            if cursor:
                cursor.close()
            if self.connection:
                self.db_config.close_connection(self.connection)
                self.connection = None
                
    def save_appointment(self):
        """
        Save appointment data
        """
        # Validate required fields
        patient_name = self.patient_var.get().strip()
        date = self.date_entry.get_date()
        heure = self.heure_entry.get().strip()
        
        if not patient_name or not date or not heure:
            messagebox.showerror("Erreur", "Les champs Patient, Date et Heure sont obligatoires")
            return
        
        # Get patient ID
        patient_id = self.patient_id_map.get(patient_name)
        if not patient_id:
            messagebox.showerror("Erreur", "Patient non valide")
            return
        
        # Get form data
        type_ = self.type_entry.get().strip() or None
        status = self.status_var.get()
        
        # Connect to database
        self.connection = self.db_config.connect()
        
        if not self.connection:
            messagebox.showerror("Erreur", "Impossible de se connecter à la base de données")
            return
        
        try:
            cursor = self.connection.cursor()
            
            if self.mode == "add":
                # Insert new appointment
                query = """
                    INSERT INTO rendezvous (patient_id, date, heure, type, status)
                    VALUES (%s, %s, %s, %s, %s)
                """
                cursor.execute(query, (patient_id, date, heure, type_, status))
                self.connection.commit()
                
                messagebox.showinfo("Succès", "Rendez-vous ajouté avec succès")
            else:
                # Update existing appointment
                query = """
                    UPDATE rendezvous 
                    SET patient_id = %s, date = %s, heure = %s, type = %s, status = %s
                    WHERE id = %s
                """
                cursor.execute(query, (patient_id, date, heure, type_, status, self.appointment_id))
                self.connection.commit()
                
                messagebox.showinfo("Succès", "Rendez-vous modifié avec succès")
                
            # Refresh parent data
            self.parent.load_appointments()
            
            # Close form
            self.destroy()
            
        except Exception as e:
            messagebox.showerror("Erreur", f"Erreur lors de l'enregistrement: {e}")
        
        finally:
            if cursor:
                cursor.close()
            if self.connection:
                self.db_config.close_connection(self.connection)
                self.connection = None
                
    def destroy(self):
        """
        Override destroy to release grab
        """
        self.grab_release()
        super().destroy()
