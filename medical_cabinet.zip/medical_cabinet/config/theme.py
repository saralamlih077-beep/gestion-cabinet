"""
Theme and Color Configuration
Professional UI colors for Medical Cabinet System
"""

# Professional color palette
COLORS = {
    # Primary Colors (Blue tones)
    'primary': '#1E88E5',           # Bright blue
    'primary_dark': '#1565C0',      # Darker blue
    'primary_light': '#42A5F5',     # Light blue
    
    # Secondary Colors (Turquoise)
    'secondary': '#00ACC1',         # Turquoise
    'secondary_dark': '#00838F',    # Dark turquoise
    'secondary_light': '#26C6DA',   # Light turquoise
    
    # Neutral Colors
    'white': '#FFFFFF',
    'black': '#000000',
    'gray_light': '#F5F5F5',
    'gray': '#E0E0E0',
    'gray_dark': '#9E9E9E',
    'gray_darker': '#616161',
    
    # Success/Error/Warning
    'success': '#4CAF50',
    'error': '#F44336',
    'warning': '#FFC107',
    'info': '#2196F3',
    
    # Sidebar colors
    'sidebar_bg': '#1E88E5',
    'sidebar_hover': '#1565C0',
    'sidebar_text': '#FFFFFF',
    
    # Header colors
    'header_bg': '#FFFFFF',
    'header_text': '#212121',
    
    # Card colors
    'card_bg': '#FFFFFF',
    'card_border': '#E0E0E0',
    
    # Button colors
    'btn_primary': '#1E88E5',
    'btn_primary_hover': '#1565C0',
    'btn_secondary': '#00ACC1',
    'btn_secondary_hover': '#00838F',
    'btn_success': '#4CAF50',
    'btn_success_hover': '#388E3C',
    'btn_danger': '#F44336',
    'btn_danger_hover': '#D32F2F',
    'btn_light': '#F5F5F5',
    'btn_light_hover': '#E0E0E0',
    
    # Text colors
    'text_primary': '#212121',
    'text_secondary': '#757575',
    'text_light': '#FFFFFF',
    
    # Notification colors
    'notif_pending': '#FFC107',
    'notif_confirmed': '#4CAF50',
    'notif_completed': '#2196F3',
    'notif_cancelled': '#F44336',
}

# CustomTkinter theme configuration
THEME = {
    "appearance_mode": "System",
    "color_theme": "blue",
    "font_family": "Segoe UI",
    "font_size": 12,
    "border_radius": 8,
    "button_corner_radius": 6,
    "entry_corner_radius": 6,
}

# UI Styles
STYLES = {
    'header_font': ('Segoe UI', 24, 'bold'),
    'title_font': ('Segoe UI', 18, 'bold'),
    'subtitle_font': ('Segoe UI', 14, 'bold'),
    'body_font': ('Segoe UI', 12),
    'small_font': ('Segoe UI', 10),
    
    'sidebar_width': 250,
    'header_height': 60,
    'card_padding': 20,
    'button_padding': 10,
    
    'border_width': 1,
    'shadow_offset': 2,
}
