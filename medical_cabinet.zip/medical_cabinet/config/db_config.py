"""
Database Configuration Module
Configuration for MySQL connection
"""

import mysql.connector
from mysql.connector import Error

class DatabaseConfig:
    """
    Database configuration and connection management
    """
    
    def __init__(self, host='localhost', database='medical_cabinet', 
                 user='root', password='sarasara2007@'):
        """
        Initialize database configuration
        
        Args:
            host: Database host (default: localhost)
            database: Database name (default: medical_cabinet)
            user: Database username (default: root)
            password: Database password (default: empty)
        """
        self.host = host
        self.database = database
        self.user = user
        self.password = password
        
    def connect(self):
        """
        Establish database connection
        
        Returns:
            MySQL connection object or None if failed
        """
        try:
            connection = mysql.connector.connect(
                host=self.host,
                database=self.database,
                user=self.user,
                password=self.password
            )
            
            if connection.is_connected():
                print("✅ Connected to MySQL database")
                return connection
                
        except Error as e:
            print(f"❌ Error connecting to MySQL: {e}")
            return None
            
    def close_connection(self, connection):
        """
        Close database connection
        
        Args:
            connection: MySQL connection object
        """
        if connection and connection.is_connected():
            connection.close()
            print("✅ Connection closed")


# Default database configuration
DB_CONFIG = {
    'host': 'localhost',
    'database': 'medical_cabinet',
    'user': 'root',
    'password': 'sarasara2007@'
}