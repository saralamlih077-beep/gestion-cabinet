"""
Patient Form
Modal window for adding/editing patient information
"""

import customtkinter as ctk
from tkinter import messagebox
from datetime import datetime

class PatientForm(ctk.CTkToplevel):
    """
    Patient form modal window
    """
    
    def __init__(self, parent, db_config, mode="add", patient_id=None):
        super().__init__(parent)
        
        # Configure window
        self.title("Patient Form" if mode == "add" else "Modifier Patient")
        self.geometry("500x600")
        self.resizable(False, False)
        
        # Set modal
        self.transient(parent)
        self.grab_set()
        
        # Initialize
        self.parent = parent
        self.db_config = db_config
        self.mode = mode
        self.patient_id = patient_id
        self.connection = None
        
        # Create UI
        self.create_widgets()
        
        # Load patient data if editing
        if mode == "edit" and patient_id:
            self.load_patient_data()
        
    def create_widgets(self):
        """
        Create form widgets
        """
        # Main frame
        self.main_frame = ctk.CTkFrame(
            self,
            fg_color="white"
        )
        self.main_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Title
        self.title_label = ctk.CTkLabel(
            self.main_frame,
            text="Ajouter un Patient" if self.mode == "add" else "Modifier Patient",
            font=("Segoe UI", 20, "bold"),
            text_color="#1E88E5"
        )
        self.title_label.pack(pady=(0, 20))
        
        # Form fields
        self.form_frame = ctk.CTkScrollableFrame(
            self.main_frame,
            fg_color="transparent"
        )
        self.form_frame.pack(fill="both", expand=True)
        
        # Nom
        self.nom_label = ctk.CTkLabel(
            self.form_frame,
            text="Nom *",
            font=("Segoe UI", 12, "bold"),
            text_color="#212121",
            anchor="w"
        )
        self.nom_label.pack(fill="x", pady=(0, 5))
        
        self.nom_entry = ctk.CTkEntry(
            self.form_frame,
            placeholder_text="Entrez le nom",
            font=("Segoe UI", 12),
            height=35,
            corner_radius=6,
            fg_color="#F5F5F5",
            border_color="#E0E0E0",
            border_width=1
        )
        self.nom_entry.pack(fill="x", pady=(0, 15))
        
        # Prénom
        self.prenom_label = ctk.CTkLabel(
            self.form_frame,
            text="Prénom *",
            font=("Segoe UI", 12, "bold"),
            text_color="#212121",
            anchor="w"
        )
        self.prenom_label.pack(fill="x", pady=(0, 5))
        
        self.prenom_entry = ctk.CTkEntry(
            self.form_frame,
            placeholder_text="Entrez le prénom",
            font=("Segoe UI", 12),
            height=35,
            corner_radius=6,
            fg_color="#F5F5F5",
            border_color="#E0E0E0",
            border_width=1
        )
        self.prenom_entry.pack(fill="x", pady=(0, 15))
        
        # CIN
        self.cin_label = ctk.CTkLabel(
            self.form_frame,
            text="CIN",
            font=("Segoe UI", 12, "bold"),
            text_color="#212121",
            anchor="w"
        )
        self.cin_label.pack(fill="x", pady=(0, 5))
        
        self.cin_entry = ctk.CTkEntry(
            self.form_frame,
            placeholder_text="Numéro CIN",
            font=("Segoe UI", 12),
            height=35,
            corner_radius=6,
            fg_color="#F5F5F5",
            border_color="#E0E0E0",
            border_width=1
        )
        self.cin_entry.pack(fill="x", pady=(0, 15))
        
        # Âge
        self.age_label = ctk.CTkLabel(
            self.form_frame,
            text="Âge",
            font=("Segoe UI", 12, "bold"),
            text_color="#212121",
            anchor="w"
        )
        self.age_label.pack(fill="x", pady=(0, 5))
        
        self.age_entry = ctk.CTkEntry(
            self.form_frame,
            placeholder_text="Âge en années",
            font=("Segoe UI", 12),
            height=35,
            corner_radius=6,
            fg_color="#F5F5F5",
            border_color="#E0E0E0",
            border_width=1
        )
        self.age_entry.pack(fill="x", pady=(0, 15))
        
        # Téléphone
        self.telephone_label = ctk.CTkLabel(
            self.form_frame,
            text="Téléphone",
            font=("Segoe UI", 12, "bold"),
            text_color="#212121",
            anchor="w"
        )
        self.telephone_label.pack(fill="x", pady=(0, 5))
        
        self.telephone_entry = ctk.CTkEntry(
            self.form_frame,
            placeholder_text="Numéro de téléphone",
            font=("Segoe UI", 12),
            height=35,
            corner_radius=6,
            fg_color="#F5F5F5",
            border_color="#E0E0E0",
            border_width=1
        )
        self.telephone_entry.pack(fill="x", pady=(0, 15))
        
        # Adresse
        self.adresse_label = ctk.CTkLabel(
            self.form_frame,
            text="Adresse",
            font=("Segoe UI", 12, "bold"),
            text_color="#212121",
            anchor="w"
        )
        self.adresse_label.pack(fill="x", pady=(0, 5))
        
        self.adresse_textbox = ctk.CTkTextbox(
            self.form_frame,
            font=("Segoe UI", 12),
            height=80,
            corner_radius=6,
            fg_color="#F5F5F5",
            border_color="#E0E0E0",
            border_width=1
        )
        self.adresse_textbox.pack(fill="x", pady=(0, 15))
        
        # Buttons
        self.button_frame = ctk.CTkFrame(
            self.main_frame,
            fg_color="transparent"
        )
        self.button_frame.pack(fill="x", pady=(10, 0))
        
        self.cancel_btn = ctk.CTkButton(
            self.button_frame,
            text="Annuler",
            font=("Segoe UI", 12, "bold"),
            height=35,
            width=120,
            fg_color="#F44336",
            hover_color="#D32F2F",
            command=self.destroy
        )
        self.cancel_btn.pack(side="right", padx=(10, 0))
        
        self.save_btn = ctk.CTkButton(
            self.button_frame,
            text="Enregistrer" if self.mode == "add" else "Modifier",
            font=("Segoe UI", 12, "bold"),
            height=35,
            width=120,
            fg_color="#1E88E5",
            hover_color="#1565C0",
            command=self.save_patient
        )
        self.save_btn.pack(side="right")
        
    def load_patient_data(self):
        """
        Load patient data for editing
        """
        # Connect to database
        self.connection = self.db_config.connect()
        
        if not self.connection:
            messagebox.showerror("Erreur", "Impossible de se connecter à la base de données")
            self.destroy()
            return
        
        try:
            cursor = self.connection.cursor(dictionary=True)
            query = "SELECT * FROM patients WHERE id = %s"
            cursor.execute(query, (self.patient_id,))
            patient = cursor.fetchone()
            
            if patient:
                self.nom_entry.insert(0, patient['nom'])
                self.prenom_entry.insert(0, patient['prenom'])
                self.cin_entry.insert(0, patient['cin'] or "")
                self.age_entry.insert(0, str(patient['age']) if patient['age'] else "")
                self.telephone_entry.insert(0, patient['telephone'] or "")
                self.adresse_textbox.insert("1.0", patient['adresse'] or "")
            else:
                messagebox.showerror("Erreur", "Patient non trouvé")
                self.destroy()
                
        except Exception as e:
            messagebox.showerror("Erreur", f"Erreur lors du chargement: {e}")
            self.destroy()
        
        finally:
            if cursor:
                cursor.close()
            if self.connection:
                self.db_config.close_connection(self.connection)
                self.connection = None
                
    def save_patient(self):
        """
        Save patient data
        """
        # Validate required fields
        nom = self.nom_entry.get().strip()
        prenom = self.prenom_entry.get().strip()
        
        if not nom or not prenom:
            messagebox.showerror("Erreur", "Les champs Nom et Prénom sont obligatoires")
            return
        
        # Get form data
        cin = self.cin_entry.get().strip() or None
        age = self.age_entry.get().strip()
        age = int(age) if age and age.isdigit() else None
        telephone = self.telephone_entry.get().strip() or None
        adresse = self.adresse_textbox.get("1.0", "end").strip() or None
        
        # Connect to database
        self.connection = self.db_config.connect()
        
        if not self.connection:
            messagebox.showerror("Erreur", "Impossible de se connecter à la base de données")
            return
        
        try:
            cursor = self.connection.cursor()
            
            if self.mode == "add":
                # Insert new patient
                query = """
                    INSERT INTO patients (nom, prenom, cin, age, telephone, adresse)
                    VALUES (%s, %s, %s, %s, %s, %s)
                """
                cursor.execute(query, (nom, prenom, cin, age, telephone, adresse))
                self.connection.commit()
                
                messagebox.showinfo("Succès", "Patient ajouté avec succès")
            else:
                # Update existing patient
                query = """
                    UPDATE patients 
                    SET nom = %s, prenom = %s, cin = %s, age = %s, telephone = %s, adresse = %s
                    WHERE id = %s
                """
                cursor.execute(query, (nom, prenom, cin, age, telephone, adresse, self.patient_id))
                self.connection.commit()
                
                messagebox.showinfo("Succès", "Patient modifié avec succès")
                
            # Refresh parent data
            self.parent.load_patients()
            
            # Close form
            self.destroy()
            
        except Exception as e:
            messagebox.showerror("Erreur", f"Erreur lors de l'enregistrement: {e}")
        
        finally:
            if cursor:
                cursor.close()
            if self.connection:
                self.db_config.close_connection(self.connection)
                self.connection = None
                
    def destroy(self):
        """
        Override destroy to release grab
        """
        self.grab_release()
        super().destroy()
